const cityInput = document.getElementById("cityInput");
const searchBtn = document.getElementById("searchBtn");
const locationBtn = document.getElementById("locationBtn");
const errorMsg = document.getElementById("errorMsg");

// UI Elements
const cityName = document.getElementById("cityName");
const currentDate = document.getElementById("currentDate");
const weatherDesc = document.getElementById("weatherDesc");
const temp = document.getElementById("temp");
const weatherIcon = document.getElementById("weatherIcon");
const feelsLike = document.getElementById("feelsLike");
const humidity = document.getElementById("humidity");
const windSpeed = document.getElementById("windSpeed");
const visibility = document.getElementById("visibility");
const sunrise = document.getElementById("sunrise");
const sunset = document.getElementById("sunset");
const forecastContainer = document.getElementById("forecastContainer");
const hourlyContainer = document.getElementById("hourlyContainer");

// Database for Instant Testing
const mockDatabase = {
  "london": { name: "London, GB", temp: 18, desc: "Light Rain", icon: "10d", feels: 17, hum: 78, wind: 15, vis: 8.5, sunR: "06:15 AM", sunS: "06:30 PM" },
  "dhaka": { name: "Dhaka, BD", temp: 32, desc: "Scattered Clouds", icon: "03d", feels: 36, hum: 82, wind: 10, vis: 10.0, sunR: "05:52 AM", sunS: "05:40 PM" },
  "new york": { name: "New York, US", temp: 22, desc: "Clear Sky", icon: "01d", feels: 22, hum: 55, wind: 18, vis: 10.0, sunR: "06:45 AM", sunS: "06:20 PM" },
  "tokyo": { name: "Tokyo, JP", temp: 25, desc: "Few Clouds", icon: "02d", feels: 26, hum: 60, wind: 12, vis: 9.0, sunR: "05:30 AM", sunS: "05:15 PM" }
};

function renderWeather(city) {
  const key = city.trim().toLowerCase();
  
  // If city exists in database use it, else generate realistic weather data
  const data = mockDatabase[key] || {
    name: `${city.charAt(0).toUpperCase() + city.slice(1)}, Global`,
    temp: Math.floor(Math.random() * 10) + 20,
    desc: "Partly Cloudy",
    icon: "02d",
    feels: Math.floor(Math.random() * 10) + 21,
    hum: Math.floor(Math.random() * 30) + 50,
    wind: Math.floor(Math.random() * 15) + 8,
    vis: 10.0,
    sunR: "06:00 AM",
    sunS: "06:15 PM"
  };

  // Update Main UI
  cityName.textContent = data.name;
  currentDate.textContent = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
  weatherDesc.textContent = data.desc;
  temp.textContent = `${data.temp}°C`;
  feelsLike.textContent = `${data.feels}°C`;
  humidity.textContent = `${data.hum}%`;
  windSpeed.textContent = `${data.wind} km/h`;
  visibility.textContent = `${data.vis} km`;
  sunrise.textContent = data.sunR;
  sunset.textContent = data.sunS;
  weatherIcon.src = `https://openweathermap.org/img/wn/${data.icon}@4x.png`;

  renderHourly();
  renderForecast();
  errorMsg.style.display = "none";
}

// Render Hourly Forecast Cards
function renderHourly() {
  hourlyContainer.innerHTML = "";
  const times = ["12 PM", "3 PM", "6 PM", "9 PM", "12 AM", "3 AM", "6 AM", "9 AM"];
  times.forEach(t => {
    hourlyContainer.innerHTML += `
      <div class="hourly-item">
        <span class="time">${t}</span>
        <img src="https://openweathermap.org/img/wn/02d.png" alt="weather">
        <span class="temp">${Math.floor(Math.random() * 5) + 20}°C</span>
      </div>
    `;
  });
}

// Render 5-Day Forecast List
function renderForecast() {
  forecastContainer.innerHTML = "";
  const days = ["Sat", "Sun", "Mon", "Tue", "Wed"];
  days.forEach(d => {
    forecastContainer.innerHTML += `
      <div class="forecast-item">
        <span class="day">${d}</span>
        <img src="https://openweathermap.org/img/wn/01d@2x.png" alt="weather">
        <span class="temp-range">${Math.floor(Math.random() * 6) + 20}°C</span>
      </div>
    `;
  });
}

// Event Listeners
searchBtn.addEventListener("click", () => {
  if (cityInput.value.trim()) renderWeather(cityInput.value);
});

cityInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter" && cityInput.value.trim()) {
    renderWeather(cityInput.value);
  }
});

locationBtn.addEventListener("click", () => {
  renderWeather("Dhaka");
});

// Initial Load
renderWeather("London");